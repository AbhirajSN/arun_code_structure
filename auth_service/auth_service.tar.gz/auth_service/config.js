var config;
var fs        = require('fs')
var conf_path = '/etc/drlsop/nodeconfig_auth.json';

module.exports  = function(env){
    console.log('env', env);
    if(fs.existsSync(conf_path)){
      console.log('file exist in conf_path');
      return (require(conf_path));
    } else {
      console.log('file not exist in conf_path');
      if(process.env.NODE_ENV === 'prod' || env === 'prod'){
        console.log("Conf Loading for production");
        config = {
          ip   : process.env.IP || 'localhost',
          port : process.env.PORT || 6060,
          mongodb : ({
              uri: process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost:27017/DRL_AUTH'
          })  
        } 
        return config;
      } else if (process.env.NODE_ENV === 'stag' || env === 'stag') {  
        console.log("Conf Loading for staging");
        config = {
          ip   : process.env.IP || 'localhost',
          port : process.env.PORT || 6060,
          mongodb : ({
              uri: process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost:27017/DRL_AUTH'
          })  
        } 
        return config;
      } else {
        console.log("Conf Loading for development");
        config = {
          ip   : process.env.IP || 'localhost',
          port : process.env.PORT || 6060,
          creator_server: 'http://192.168.2.40/api',
          mongodb : ({
              uri: process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost:27017/DRL_AUTH'
          })  
        } 
        return config;
      }
    }            
}

