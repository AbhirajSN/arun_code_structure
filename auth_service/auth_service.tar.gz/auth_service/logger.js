var fs      = require('fs');
var path    = require('path');
let request = require('request');
let config;

exports.init = function(app_config){
  config = app_config;
}

let logger_api = function(rxd_url, log_data){
    var options = { 
        method: 'POST',
        url: rxd_url,
        headers: { 
            'cache-control': 'no-cache',
            //'x-access-token': token,
            'content-type': 'application/json' 
        },
        body: JSON.stringify(log_data)
        
    };
  
    request(options, function (err, response, body) {
        if (err) {
           console.log("Error in logger request HTTP POST call", err);
        } else if(response.statusCode == 500 || response.statusCode == 502){
            console.log("Remote Server Not Reachable, Error : ", response.statusCode);
        } else {
            console.log("logs updated to Logger Service Successfully");
        }    
    });
}

let get_ip = (req)=>{
    return req.headers['x-forwarded-for'] || req.connection.remoteAddress;
}

let parse_req_data = function(req){
    if(!req){
        return;
    } else {
        return {             
            "IP"            : get_ip(req),
            "email"         : req.body.req_user?req.body.req_user.email:"",
            "sessionID"     : req.body.token,
            "uid"           : req.body.req_user?req.body.req_user._id:"",
            "url"           : req.originalUrl,
            "method"        : req.method,
            "browsertype"   : req.get('User-Agent'),
            "service"       : req.headers.portal ? req.headers.portal: 'Admin'
        }
    }
}

exports.log = function(action, fromfile, msg){
}

exports.info = function(req, action, fromfile, msg, detail, res_status, log_type="d") { //d - developer type, a - audit log
    let req_meta_data = parse_req_data(req);
    let meta_data = {   "action": action,
                        "filename": path.basename(fromfile),
                        "msg": msg, "detail":detail,
                        "res_status": res_status, "type": log_type 
                    };

    let log_meta_data =  Object.assign(req_meta_data, meta_data); 
    let url = config.auditService+'/info';
    logger_api(url, log_meta_data);
}

exports.error = function(req, action, fromfile, msg, detail, res_status, log_type="d") {
    let req_meta_data = parse_req_data(req);
    let meta_data = {   "action": action,
                        "filename": path.basename(fromfile),
                        "msg": msg, "detail":detail,
                        "res_status": res_status, "type": log_type };

    let log_meta_data =  Object.assign(req_meta_data, meta_data); 
    let url = config.auditService+'/error';
    logger_api(url, log_meta_data);
}
