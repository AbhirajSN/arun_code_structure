'use strict';

exports = module.exports = function(app, mongoose) {
  require('./schema/User')(app, mongoose);
  require('./schema/Role')(app, mongoose);
  require('./schema/SavedSop')(app, mongoose);
  require('./schema/Notifications')(app, mongoose);
  require('./schema/Quiz')(app, mongoose);
  require('./schema/Approval')(app, mongoose);
  require('./schema/Comment')(app, mongoose);
};
